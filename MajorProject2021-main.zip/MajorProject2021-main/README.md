# MajorProject2021
Online Decentralized voting system using Blockchain 
